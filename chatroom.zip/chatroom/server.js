const express = require("express");
const WebSocket = require("ws");
const http = require("http");

const PORT = 8080;
const server = http.createServer(express);
const wss = new WebSocket.Server({server});

var history = [];

server.listen(PORT, function(){
    console.log(`Palvelin kuuntelee portissa ${PORT}`);
})

wss.on("connection", function connection(socket){
    console.log("Asiakas otti yhteden.");
    history.forEach(msg => socket.send(msg.toString()));

    socket.on("message", function incoming(data){
        console.log(`Saatiin asiakkaalta viesti: ${data}`);
        history.push(data);
        history.forEach(msg => socket.send(msg.toString()));

        wss.clients.forEach(function each(client){
            if(client !== socket && client.readyState === WebSocket.OPEN){
                client.send(data.toString());
            }
        })
    })
})